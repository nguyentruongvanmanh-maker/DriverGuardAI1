plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.driverguard.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.driverguard.ai"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-demo"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.camera:camera-core:1.4.2")
    implementation("androidx.camera:camera-camera2:1.4.2")
    implementation("androidx.camera:camera-lifecycle:1.4.2")
    implementation("androidx.camera:camera-view:1.4.2")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// The official MediaPipe model is downloaded into app/src/main/assets before build.
val downloadFaceModel by tasks.registering {
    val model = layout.projectDirectory.file("src/main/assets/face_landmarker.task")
    outputs.file(model)
    doLast {
        if (!model.asFile.exists() || model.asFile.length() < 1_000_000) {
            model.asFile.parentFile.mkdirs()
            val urls = listOf(
                "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",
                "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task"
            )
            var success = false
            var lastError: Exception? = null
            for (url in urls) {
                try {
                    val connection: java.net.URLConnection = java.net.URL(url).openConnection()
                    connection.setConnectTimeout(20000)
                    connection.setReadTimeout(60000)
                    connection.getInputStream().use { input: java.io.InputStream ->
                        model.asFile.outputStream().use { output: java.io.OutputStream ->
                            input.copyTo(output)
                        }
                    }
                    if (model.asFile.exists() && model.asFile.length() > 1_000_000) { success = true; break }
                } catch (e: Exception) { lastError = e }
            }
            if (!success) throw GradleException("Không tải được face_landmarker.task. Kiểm tra Internet rồi Build lại. Lỗi: ${lastError?.message}")
        }
    }
}
tasks.named("preBuild").configure { dependsOn(downloadFaceModel) }
