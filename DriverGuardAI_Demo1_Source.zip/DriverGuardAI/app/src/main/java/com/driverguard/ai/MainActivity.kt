package com.driverguard.ai

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var overlay: FaceOverlay
    private lateinit var status: TextView
    private lateinit var eyeValue: TextView
    private lateinit var headValue: TextView
    private lateinit var eventLog: TextView
    private lateinit var startButton: Button
    private var landmarker: FaceLandmarker? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var eyeClosedSince = 0L
    private var headDownSince = 0L
    private var lastAlert = 0L
    private var baselineNoseRatio: Float? = null
    private val logLines = mutableListOf<String>()

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else status.text = "Cần cấp quyền camera để thử nghiệm"
    }
    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        buildUi()
        startButton.setOnClickListener {
            if (running) stopCamera() else ensurePermissionAndStart()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18); setBackgroundColor(0xFF101827.toInt()) }
        val title = TextView(this).apply { text = "DRIVERGUARD AI"; textSize = 23f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER; setPadding(0, 4, 0, 4) }
        val subtitle = TextView(this).apply { text = "DEMO 1.0 • Theo dõi mắt và tư thế đầu"; textSize = 13f; setTextColor(0xFF9FB0C7.toInt()); gravity = Gravity.CENTER; setPadding(0, 0, 0, 12) }
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        overlay = FaceOverlay(this)
        val cameraFrame = android.widget.FrameLayout(this).apply {
            addView(preview, android.widget.FrameLayout.LayoutParams(-1, -1))
            addView(overlay, android.widget.FrameLayout.LayoutParams(-1, -1))
        }
        status = makeText("CHƯA KHỞI ĐỘNG", 18f, 0xFFB8C6D9.toInt())
        eyeValue = makeText("Mắt: --", 15f, 0xFFFFFFFF.toInt())
        headValue = makeText("Tư thế đầu: --", 15f, 0xFFFFFFFF.toInt())
        startButton = Button(this).apply { text = "BẮT ĐẦU CAMERA" }
        val historyTitle = makeText("LỊCH SỬ CẢNH BÁO", 14f, 0xFF63D9C2.toInt())
        eventLog = makeText("Chưa có sự kiện.", 13f, 0xFFCBD5E1.toInt())
        root.addView(title)
        root.addView(subtitle)
        root.addView(cameraFrame, LinearLayout.LayoutParams(-1, 0, 1f).apply { height = 0 })
        root.addView(status)
        root.addView(eyeValue)
        root.addView(headValue)
        root.addView(startButton)
        root.addView(historyTitle)
        root.addView(eventLog)
        setContentView(root)
    }

    private fun makeText(value: String, size: Float, color: Int) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); setPadding(2, 7, 2, 7)
    }

    private fun ensurePermissionAndStart() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        try {
            val base = BaseOptions.builder().setModelAssetPath("face_landmarker.task").build()
            val options = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.VIDEO)
                .setNumFaces(1)
                .setOutputFaceBlendshapes(true)
                .setOutputFacialTransformationMatrixes(true)
                .setMinFaceDetectionConfidence(0.5f)
                .setMinFacePresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .build()
            landmarker = FaceLandmarker.createFromOptions(this, options)
            val providerFuture = ProcessCameraProvider.getInstance(this)
            providerFuture.addListener({
                val provider = providerFuture.get()
                val cameraPreview = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, cameraPreview)
                running = true
                startButton.text = "DỪNG CAMERA"
                status.text = "ĐANG THEO DÕI – HÃY NGỒI YÊN ĐỂ KIỂM TRA"
                handler.post(frameLoop)
            }, ContextCompat.getMainExecutor(this))
        } catch (e: Exception) {
            status.text = "Không khởi động được AI: ${e.message ?: "lỗi không xác định"}"
            landmarker?.close(); landmarker = null
        }
    }

    private val frameLoop = object : Runnable {
        override fun run() {
            if (!running) return
            val bitmap = preview.bitmap
            if (bitmap != null) {
                val copy = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                worker.execute {
                    try {
                        val mpImage = BitmapImageBuilder(copy).build()
                        val result = landmarker?.detectForVideo(mpImage, android.os.SystemClock.uptimeMillis())
                        if (result != null) processResult(result)
                    } catch (_: Exception) {
                        runOnUiThread { status.text = "Đang chờ hình ảnh camera ổn định…" }
                    } finally { copy.recycle() }
                }
            }
            handler.postDelayed(this, 450)
        }
    }

    private fun processResult(result: FaceLandmarkerResult) {
        val faces = result.faceLandmarks()
        if (faces.isEmpty()) {
            runOnUiThread { status.text = "CHƯA THẤY KHUÔN MẶT"; eyeValue.text = "Mắt: chưa nhận diện"; overlay.setBox(null) }
            return
        }
        val points = faces[0]
        var minX = 1f; var minY = 1f; var maxX = 0f; var maxY = 0f
        points.forEach { p -> minX = min(minX, p.x()); minY = min(minY, p.y()); maxX = max(maxX, p.x()); maxY = max(maxY, p.y()) }
        val leftEar = ear(points, intArrayOf(33, 160, 158, 133, 153, 144))
        val rightEar = ear(points, intArrayOf(362, 385, 387, 263, 373, 380))
        val averageEar = (leftEar + rightEar) / 2f
        val now = System.currentTimeMillis()
        val eyesClosed = averageEar < 0.18f
        if (eyesClosed) { if (eyeClosedSince == 0L) eyeClosedSince = now } else eyeClosedSince = 0L
        val eyeDuration = if (eyeClosedSince == 0L) 0L else now - eyeClosedSince

        // Simple demo heuristic: track nose position relative to the eye line.
        // It is not a validated head-pose or drowsiness classifier.
        val eyeLine = (points[33].y() + points[263].y()) / 2f
        val noseRatio = (points[1].y() - eyeLine) / max(0.08f, maxY - minY)
        if (baselineNoseRatio == null && !eyesClosed) baselineNoseRatio = noseRatio
        val baseline = baselineNoseRatio ?: noseRatio
        val headDown = noseRatio - baseline > 0.12f
        if (headDown) { if (headDownSince == 0L) headDownSince = now } else headDownSince = 0L
        val headDuration = if (headDownSince == 0L) 0L else now - headDownSince

        val alert = eyeDuration >= 1500L || headDuration >= 1800L
        val reason = when { eyeDuration >= 1500L -> "Nhắm mắt kéo dài"; headDuration >= 1800L -> "Đầu cúi kéo dài"; else -> "" }
        runOnUiThread {
            overlay.setBox(floatArrayOf(minX, minY, maxX, maxY))
            eyeValue.text = "Mắt: ${if (eyesClosed) "có vẻ đang nhắm" else "đang mở"} • EAR ${"%.2f".format(averageEar)}"
            headValue.text = "Tư thế đầu: ${if (headDown) "cúi thấp" else "ổn định"}"
            status.text = if (alert) "CẢNH BÁO: $reason" else "ĐANG THEO DÕI – CHƯA CÓ CẢNH BÁO"
            status.setTextColor(if (alert) 0xFFFF7373.toInt() else 0xFF63D9C2.toInt())
            if (alert && now - lastAlert > 10000L) {
                lastAlert = now
                addEvent(reason)
                sendLocalNotification(reason)
            }
        }
    }

    private fun ear(p: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>, idx: IntArray): Float {
        fun dist(a: Int, b: Int): Float {
            val dx = p[idx[a]].x() - p[idx[b]].x(); val dy = p[idx[a]].y() - p[idx[b]].y()
            return kotlin.math.sqrt(dx * dx + dy * dy)
        }
        val vertical = dist(1, 5) + dist(2, 4)
        val horizontal = 2f * dist(0, 3)
        return if (horizontal <= 0f) 0f else vertical / horizontal
    }

    private fun addEvent(reason: String) {
        val line = "${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())} • $reason"
        logLines.add(0, line)
        if (logLines.size > 8) logLines.removeAt(logLines.lastIndex)
        eventLog.text = logLines.joinToString("\n")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("driverguard_alerts", "DriverGuard cảnh báo", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun sendLocalNotification(reason: String) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = NotificationCompat.Builder(this, "driverguard_alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("DriverGuard AI – Cảnh báo thử nghiệm")
            .setContentText(reason)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(101, notification)
    }

    private fun stopCamera() {
        running = false; handler.removeCallbacks(frameLoop)
        ProcessCameraProvider.getInstance(this).get().unbindAll()
        landmarker?.close(); landmarker = null
        startButton.text = "BẮT ĐẦU CAMERA"
        status.text = "ĐÃ DỪNG"
        overlay.setBox(null)
    }

    override fun onDestroy() {
        stopCamera(); worker.shutdown(); super.onDestroy()
    }
}

class FaceOverlay(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF35E0BD.toInt(); style = Paint.Style.STROKE; strokeWidth = 5f }
    @Volatile private var box: FloatArray? = null
    fun setBox(value: FloatArray?) { box = value; postInvalidate() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = box ?: return
        val left = b[0] * width; val top = b[1] * height; val right = b[2] * width; val bottom = b[3] * height
        canvas.drawRoundRect(left, top, right, bottom, 18f, 18f, paint)
    }
}
