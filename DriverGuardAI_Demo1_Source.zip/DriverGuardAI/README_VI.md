# DriverGuard AI Demo 1.0 (Android)

Bản thử nghiệm native Android: camera trước, MediaPipe Face Landmarker, ước lượng trạng thái mắt, heuristic cúi đầu đơn giản, cảnh báo trên màn hình, thông báo cục bộ trên chính điện thoại và nhật ký sự kiện.

## Giới hạn quan trọng
- Đây là nguyên mẫu học tập, KHÔNG phải thiết bị an toàn lái xe và không được dùng để quyết định tài xế đủ tỉnh táo để lái xe.
- EAR và ngưỡng cúi đầu chỉ là heuristic ban đầu, có thể báo nhầm do ánh sáng, kính, góc camera, khuôn mặt và chuyển động.
- Bản này KHÔNG có còi, Firebase, thông báo từ xa, chạy nền hoặc tự động giám sát khi app đóng.
- Camera chỉ chạy khi màn hình ứng dụng đang mở.
- Người thử nghiệm cần ngồi yên; không cố tình gây buồn ngủ hoặc thử trên xe đang chạy.

## Mở và tạo APK
1. Trên laptop cài Android Studio và JDK 17.
2. Giải nén `DriverGuardAI_Demo1_Source.zip`.
3. Android Studio > Open > chọn thư mục `DriverGuardAI`.
4. Chờ Gradle Sync. Lần build đầu cần Internet để tải thư viện và model Face Landmarker vào `app/src/main/assets`.
5. Kết nối điện thoại Android bằng USB, bật Developer options và USB debugging, hoặc dùng Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug thường nằm ở `app/build/outputs/apk/debug/app-debug.apk`.

## Nếu model không tự tải
Tải model chính thức từ:
https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task
Sau đó đặt đúng tên `face_landmarker.task` vào `app/src/main/assets/` rồi Build lại.

## Thư viện
- CameraX 1.4.2
- MediaPipe Tasks Vision 0.10.14
- AndroidX AppCompat / Activity

Tài liệu MediaPipe Android: https://developers.google.com/edge/mediapipe/solutions/vision/face_landmarker/android
